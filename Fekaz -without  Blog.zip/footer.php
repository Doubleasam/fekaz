     <!-- footer -->
        <footer class="footer-bg footer-p" style="background:#282828;">
             <div class="footer-top pt-70 pb-40">
                <div class="container">
                    <div class="row justify-content-between">
                        
                          <div class="col-xl-4 col-lg-4 col-sm-6">
                            <div class="footer-widget mb-15">
                                <div class="f-widget-title mb-30">
                                   <img src="img/logo/f_logo.png" alt="img">                                   
                                </div>
                                 <p>Efficiency in Motion, Excellence in Delivery: Your Logistics Partner for Seamless Solutions</p>
                                <div class="newslater-area">
                                
                             </div>
                            </div>
                              <div class="footer-social  mt-30">                                    
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                        </div>
						<div class="col-xl-2 col-lg-2 col-sm-6">
                            <div class="footer-widget mb-30">
                                <div class="f-widget-title">
                                    <h2>Our Links</h2>
                                </div>
                                <div class="footer-link">
                                    <ul>                                        
                                        <li><a href="index">Home</a></li>
                                        <li><a href="about"> About Us</a></li>
                                        <li><a href="services"> Services </a></li>
                                        <li><a href="contact"> Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                       
                       <div class="col-xl-6 col-lg-6 col-sm-6">
                            <div class="footer-widget mb-30">
                                <div class="f-widget-title">
                                    <h2>Our Gallery</h2>
                                </div>
                                <div class="f-insta">
                                    <ul>
                                        <li><a href="img/instagram/f-galler-01.png" class="popup-image"><img src="img/instagram/f-galler-01.png" alt="img"></a></li>
                                       <li><a href="img/instagram/f-galler-02.png" class="popup-image"><img src="img/instagram/f-galler-02.png" alt="img"></a></li>
                                        <li><a href="img/instagram/f-galler-03.png" class="popup-image"><img src="img/instagram/f-galler-03.png" alt="img"></a></li>
                                        <li><a href="img/instagram/f-galler-04.png" class="popup-image"><img src="img/instagram/f-galler-04.png" alt="img"></a></li>
                                        <li><a href="img/instagram/f-galler-05.png" class="popup-image"><img src="img/instagram/f-galler-05.png" alt="img"></a></li>
                                        <li><a href="img/instagram/f-galler-06.png" class="popup-image"><img src="img/instagram/f-galler-06.png" alt="img"></a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>  
                      
                        
                    </div>
                </div>
            </div>
            <div class="copyright-wrap">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">                         
                               Copyright  © 2024 Fekaz. All rights reserved.                       
                        </div>
                    
                        
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer-end -->


		<!-- JS here -->
        <script src="js/vendor/modernizr-3.5.0.min.js"></script>
        <script src="js/vendor/jquery-3.6.0.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/ajax-form.js"></script>
        <script src="js/paroller.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/js_isotope.pkgd.min.js"></script>
        <script src="js/imagesloaded.min.js"></script>
        <script src="js/parallax.min.js"></script>
         <script src="js/jquery.waypoints.min.js"></script>
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/jquery.scrollUp.min.js"></script>
        <script src="js/jquery.meanmenu.min.js"></script>
        <script src="js/parallax-scroll.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/element-in-view.js"></script>
        <script src="js/main.js"></script>